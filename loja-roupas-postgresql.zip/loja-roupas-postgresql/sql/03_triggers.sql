-- =============================================================
-- Loja de Roupas | PostgreSQL
-- 03_triggers.sql: Controle automático de estoque (funções + triggers)
-- =============================================================

-- -------------------------------------------------------------
-- 1) Função fn_estoque_itens: estoque a cada item vendido
-- -------------------------------------------------------------
-- Trigger no Postgres = FUNÇÃO (o que fazer) + TRIGGER (quando fazer)
-- Variáveis especiais dentro da função:
--   TG_OP -> operação: 'INSERT', 'UPDATE' ou 'DELETE'
--   NEW   -> linha nova (INSERT e UPDATE)
--   OLD   -> linha antiga (UPDATE e DELETE)
--   FOUND -> true se o último comando afetou alguma linha

CREATE OR REPLACE FUNCTION fn_estoque_itens()
RETURNS TRIGGER AS $$               -- aqui começa o corpo da função
DECLARE
    v_status VARCHAR(10);           -- variável local
BEGIN
    -- Regra 1: não mexer em itens de venda cancelada
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        SELECT status INTO v_status FROM vendas WHERE id_venda = NEW.id_venda;
        IF v_status = 'cancelada' THEN
            -- RAISE EXCEPTION: gera um erro e cancela a operação
            RAISE EXCEPTION 'A venda % está cancelada; não é possível alterar itens.',
                NEW.id_venda;       -- o % é trocado por este valor
        END IF;
    END IF;

    -- INSERT: item vendido -> baixa o estoque
    IF TG_OP = 'INSERT' THEN
        UPDATE variacoes SET estoque = estoque - NEW.quantidade
         WHERE id_variacao = NEW.id_variacao
           AND estoque >= NEW.quantidade;   -- só se houver peças
        -- Se não atualizou nenhuma linha, faltou estoque
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Estoque insuficiente para a variação %.', NEW.id_variacao;
        END IF;
        RETURN NEW;          -- BEFORE: "pode gravar esta linha"

    -- UPDATE: devolve a quantidade antiga e baixa a nova
    -- (funciona até se trocar a variação do item)
    ELSIF TG_OP = 'UPDATE' THEN
        UPDATE variacoes SET estoque = estoque + OLD.quantidade
         WHERE id_variacao = OLD.id_variacao;
        UPDATE variacoes SET estoque = estoque - NEW.quantidade
         WHERE id_variacao = NEW.id_variacao
           AND estoque >= NEW.quantidade;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Estoque insuficiente para a variação %.', NEW.id_variacao;
        END IF;
        RETURN NEW;

    -- DELETE: item removido -> devolve ao estoque,
    -- mas só se a venda estiver concluída (cancelada já devolveu)
    ELSE
        SELECT status INTO v_status FROM vendas WHERE id_venda = OLD.id_venda;
        IF v_status = 'concluida' THEN
            UPDATE variacoes SET estoque = estoque + OLD.quantidade
             WHERE id_variacao = OLD.id_variacao;
        END IF;
        RETURN OLD;          -- no DELETE só existe OLD
    END IF;
END;
$$ LANGUAGE plpgsql;         -- $$ fecha o corpo | linguagem usada

-- -------------------------------------------------------------
-- 2) Trigger trg_estoque_itens: liga a função à tabela itens_venda
-- -------------------------------------------------------------
-- CREATE TRIGGER não aceita IF NOT EXISTS,
-- então apagamos antes para poder rodar o script de novo
DROP TRIGGER IF EXISTS trg_estoque_itens ON itens_venda;

CREATE TRIGGER trg_estoque_itens
BEFORE INSERT OR UPDATE OR DELETE   -- roda ANTES: se der erro, nada é gravado
ON itens_venda
FOR EACH ROW                        -- uma vez para cada linha afetada
EXECUTE FUNCTION fn_estoque_itens();

-- -------------------------------------------------------------
-- 3) Função e trigger de vendas: cancelamento e reativação
-- -------------------------------------------------------------
-- Cuida das mudanças na VENDA inteira
CREATE OR REPLACE FUNCTION fn_estoque_vendas()
RETURNS TRIGGER AS $$
BEGIN
    -- Cancelou: devolve todas as peças da venda.
    -- UPDATE ... FROM funciona como um UPDATE com JOIN
    IF TG_OP = 'UPDATE' AND OLD.status = 'concluida' AND NEW.status = 'cancelada' THEN
        UPDATE variacoes v SET estoque = v.estoque + i.quantidade
          FROM itens_venda i
         WHERE i.id_venda = NEW.id_venda AND v.id_variacao = i.id_variacao;

    -- Reativou: baixa as peças de novo
    -- (se faltar estoque, o CHECK estoque >= 0 bloqueia)
    ELSIF TG_OP = 'UPDATE' AND OLD.status = 'cancelada' AND NEW.status = 'concluida' THEN
        UPDATE variacoes v SET estoque = v.estoque - i.quantidade
          FROM itens_venda i
         WHERE i.id_venda = NEW.id_venda AND v.id_variacao = i.id_variacao;

    -- Apagou uma venda concluída: devolve ANTES do CASCADE apagar os itens
    ELSIF TG_OP = 'DELETE' AND OLD.status = 'concluida' THEN
        UPDATE variacoes v SET estoque = v.estoque + i.quantidade
          FROM itens_venda i
         WHERE i.id_venda = OLD.id_venda AND v.id_variacao = i.id_variacao;
    END IF;

    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_estoque_vendas ON vendas;
CREATE TRIGGER trg_estoque_vendas
BEFORE UPDATE OF status OR DELETE   -- UPDATE OF status: só quando o status muda
ON vendas
FOR EACH ROW
EXECUTE FUNCTION fn_estoque_vendas();
