-- =============================================================
-- Loja de Roupas | PostgreSQL
-- 06_testes.sql: Testes das regras (alguns DEVEM dar erro)
-- =============================================================

-- -------------------------------------------------------------
-- Testes: tentando quebrar o banco de propósito
-- -------------------------------------------------------------
-- Rode um por vez e compare com o resultado esperado

-- 1) Vender mais do que existe -> ERRO "Estoque insuficiente"
INSERT INTO itens_venda (id_venda, id_variacao, quantidade, preco_unitario)
VALUES (1, 10, 99, 229.90);

-- 2) Cancelar a venda 2 -> estoque da variação 9 volta de 4 para 5
UPDATE vendas SET status = 'cancelada' WHERE id_venda = 2;
SELECT produto, tamanho, cor, estoque FROM vw_estoque WHERE id_variacao = 9;

-- 3) Item em venda cancelada -> ERRO "A venda 2 está cancelada"
INSERT INTO itens_venda (id_venda, id_variacao, quantidade, preco_unitario)
VALUES (2, 1, 1, 59.90);

-- 4) Reativar a venda 2 -> estoque da variação 9 volta para 4
UPDATE vendas SET status = 'concluida' WHERE id_venda = 2;

-- 5) Mudar a quantidade de 2 para 5 -> estoque da variação 2: 23 -> 20
UPDATE itens_venda SET quantidade = 5 WHERE id_venda = 1 AND id_variacao = 2;

-- 6a) CPF com pontos (14 caracteres) -> ERRO "value too long":
--     nem chega no CHECK, porque não cabe em CHAR(11)
INSERT INTO clientes (nome, cpf) VALUES ('Teste', '123.456.789-01');

-- 6b) CPF com 11 caracteres, mas com letra -> ERRO no CHECK
INSERT INTO clientes (nome, cpf) VALUES ('Teste', '1234567890A');
