-- =============================================================
-- Loja de Roupas | PostgreSQL
-- 02_indices.sql: Índices para acelerar consultas
-- =============================================================

-- -------------------------------------------------------------
-- Índices
-- -------------------------------------------------------------
-- ÍNDICES: funcionam como o índice de um livro.
-- O Postgres só cria índice sozinho em PRIMARY KEY e UNIQUE.
-- Em chaves estrangeiras e colunas de filtro, criamos nós mesmos.
-- IF NOT EXISTS: não dá erro se o índice já existir

CREATE INDEX IF NOT EXISTS idx_produtos_categoria ON produtos (id_categoria);
CREATE INDEX IF NOT EXISTS idx_produtos_marca     ON produtos (id_marca);
CREATE INDEX IF NOT EXISTS idx_vendas_cliente     ON vendas (id_cliente);
-- data_venda: relatórios filtram por período ("vendas de outubro")
CREATE INDEX IF NOT EXISTS idx_vendas_data        ON vendas (data_venda);
CREATE INDEX IF NOT EXISTS idx_itens_variacao     ON itens_venda (id_variacao);

-- Por que não há índice em variacoes.id_produto e itens_venda.id_venda?
-- Os UNIQUE compostos já criam índices que começam por essas colunas,
-- e um índice composto serve para buscas pela PRIMEIRA coluna dele.
