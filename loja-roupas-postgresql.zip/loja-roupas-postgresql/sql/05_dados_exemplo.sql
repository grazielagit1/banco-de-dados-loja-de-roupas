-- =============================================================
-- Loja de Roupas | PostgreSQL
-- 05_dados_exemplo.sql: Dados fictícios para testar o banco
-- =============================================================

-- -------------------------------------------------------------
-- Dados de exemplo
-- -------------------------------------------------------------
-- Ordem importa: primeiro quem é referenciado, depois quem referencia
-- categorias/marcas -> clientes -> produtos -> variações -> vendas -> itens
-- Os IDs não são informados: a IDENTITY gera 1, 2, 3...

INSERT INTO categorias (nome) VALUES
 ('Camisetas'), ('Calças'), ('Vestidos'), ('Jaquetas'), ('Calçados');

INSERT INTO marcas (nome) VALUES
 ('Urban Wave'), ('Bella Moda'), ('Trilha Jeans'), ('Pé Leve');

-- CPF sem pontos nem traço, por causa do CHECK
INSERT INTO clientes (nome, cpf, email, cidade, estado) VALUES
 ('Ana Souza',      '12345678901', 'ana@email.com',   'São Paulo',      'SP'),
 ('Bruno Lima',     '23456789012', 'bruno@email.com', 'Rio de Janeiro', 'RJ'),
 ('Carla Mendes',   '34567890123', 'carla@email.com', 'Belo Horizonte', 'MG'),
 ('Diego Ferreira', '45678901234', 'diego@email.com', 'Curitiba',       'PR');

--                          (nome, descricao, categoria, marca, preço)
INSERT INTO produtos (nome, descricao, id_categoria, id_marca, preco) VALUES
 ('Camiseta Básica',     'Algodão 100%',       1, 1,  59.90),
 ('Calça Jeans Skinny',  'Jeans com elastano', 2, 3, 149.90),
 ('Vestido Midi Floral', 'Viscose estampada',  3, 2, 189.90),
 ('Jaqueta Corta-Vento', 'Impermeável',        4, 1, 229.90),
 ('Tênis Casual',        'Solado de borracha', 5, 4, 199.90);

-- -------------------------------------------------------------
-- Dados de exemplo: variações, vendas e itens
-- -------------------------------------------------------------
--                    (produto, tamanho, cor, SKU, estoque inicial)
INSERT INTO variacoes (id_produto, tamanho, cor, codigo_sku, estoque) VALUES
 (1, 'P',  'Branca', 'CAM-BAS-P-BR',  20),
 (1, 'M',  'Branca', 'CAM-BAS-M-BR',  25),
 (1, 'M',  'Preta',  'CAM-BAS-M-PT',  18),
 (1, 'G',  'Preta',  'CAM-BAS-G-PT',  12),
 (2, '38', 'Azul',   'CAL-SKI-38-AZ', 10),
 (2, '40', 'Azul',   'CAL-SKI-40-AZ',  8),
 (3, 'P',  'Rosa',   'VES-MID-P-RS',   6),
 (3, 'M',  'Rosa',   'VES-MID-M-RS',   7),
 (4, 'M',  'Verde',  'JAQ-CVE-M-VD',   5),
 (4, 'G',  'Preta',  'JAQ-CVE-G-PT',   4),
 (5, '39', 'Branco', 'TEN-CAS-39-BR',  9),
 (5, '42', 'Branco', 'TEN-CAS-42-BR',  6);

-- status não informado = 'concluida' (DEFAULT)
INSERT INTO vendas (id_cliente, data_venda, canal, forma_pagamento) VALUES
 (1, '2026-10-01 10:15', 'loja',   'pix'),
 (2, '2026-10-03 14:40', 'online', 'credito'),
 (3, '2026-10-10 16:05', 'loja',   'debito'),
 (1, '2026-10-20 11:30', 'online', 'pix');

-- Cada item inserido dispara o trigger e baixa o estoque
--                       (venda, variação, quantidade, preço pago)
INSERT INTO itens_venda (id_venda, id_variacao, quantidade, preco_unitario) VALUES
 (1,  2, 2,  59.90),
 (1,  5, 1, 149.90),
 (2,  9, 1, 229.90),
 (3,  7, 1, 189.90),
 (3, 11, 1, 199.90),
 (4,  3, 3,  55.00);    -- vendido com desconto
