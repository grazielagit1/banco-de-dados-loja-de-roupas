-- =============================================================
-- Loja de Roupas | PostgreSQL
-- 04_views.sql: Views de relatório
-- =============================================================

-- -------------------------------------------------------------
-- Views: estoque e resumo de vendas
-- -------------------------------------------------------------
-- VIEW = um SELECT salvo com nome. Não guarda dados:
-- a consulta roda de novo toda vez que a view é usada.

-- Estoque com os nomes no lugar dos IDs
CREATE OR REPLACE VIEW vw_estoque AS
SELECT p.id_produto, p.nome AS produto,   -- AS renomeia a coluna
       c.nome AS categoria, m.nome AS marca,
       v.id_variacao, v.codigo_sku, v.tamanho, v.cor, v.estoque,
       p.preco, p.ativo
  FROM variacoes v                        -- v, p, c, m são apelidos
  JOIN produtos   p ON p.id_produto   = v.id_produto
  JOIN categorias c ON c.id_categoria = p.id_categoria
  JOIN marcas     m ON m.id_marca     = p.id_marca;

-- Uma linha por venda, com o valor total
CREATE OR REPLACE VIEW vw_vendas_resumo AS
SELECT ve.id_venda, ve.data_venda, cl.nome AS cliente,
       ve.canal, ve.forma_pagamento, ve.status,
       -- COALESCE troca NULL por 0 (venda sem itens)
       COALESCE(SUM(i.quantidade), 0)                    AS qtd_itens,
       COALESCE(SUM(i.quantidade * i.preco_unitario), 0) AS valor_total
  FROM vendas ve
  JOIN clientes cl ON cl.id_cliente = ve.id_cliente
  -- LEFT JOIN: mantém a venda mesmo se ela não tiver itens
  LEFT JOIN itens_venda i ON i.id_venda = ve.id_venda
 GROUP BY ve.id_venda, cl.nome;           -- agrupa os itens de cada venda

-- -------------------------------------------------------------
-- View: ranking de produtos mais vendidos
-- -------------------------------------------------------------
-- Caminho: item -> venda -> variação -> produto
CREATE OR REPLACE VIEW vw_produtos_mais_vendidos AS
SELECT p.id_produto, p.nome AS produto,
       SUM(i.quantidade)                    AS unidades_vendidas,
       SUM(i.quantidade * i.preco_unitario) AS faturamento
  FROM itens_venda i
  -- o filtro no JOIN descarta vendas canceladas
  JOIN vendas    ve ON ve.id_venda   = i.id_venda AND ve.status = 'concluida'
  JOIN variacoes v  ON v.id_variacao = i.id_variacao
  JOIN produtos  p  ON p.id_produto  = v.id_produto
 GROUP BY p.id_produto, p.nome            -- soma todos os tamanhos/cores juntos
 ORDER BY unidades_vendidas DESC;         -- DESC: do maior para o menor

-- Como usar:
-- SELECT * FROM vw_estoque WHERE estoque <= 5;
-- SELECT * FROM vw_vendas_resumo ORDER BY data_venda;
-- SELECT * FROM vw_produtos_mais_vendidos;
