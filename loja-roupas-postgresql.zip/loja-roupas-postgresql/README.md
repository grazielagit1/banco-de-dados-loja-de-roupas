# 👕 Loja de Roupas: Banco de Dados em PostgreSQL

Projeto de estudo: o banco de dados de uma loja de roupas, construído do zero em **PostgreSQL**.

Além de criar as tabelas, o objetivo era fazer o banco **proteger os próprios dados**: impedir cadastros inválidos, controlar o estoque sozinho e gerar relatórios prontos.

Todo o código está **comentado linha a linha**, para servir de material de estudo.

---

## ✨ O que o projeto tem

- **7 tabelas relacionadas**: categorias, marcas, clientes, produtos, variações (tamanho e cor), vendas e itens de venda
- **Regras de integridade**: `PRIMARY KEY`, `FOREIGN KEY`, `UNIQUE`, `CHECK` e `DEFAULT`
- **Índices** nas chaves estrangeiras e nas colunas mais filtradas
- **Controle automático de estoque** com triggers em PL/pgSQL:
  - cada item vendido dá baixa no estoque
  - não deixa vender sem estoque suficiente
  - cancelar uma venda devolve as peças; reativar dá baixa de novo
- **3 views de relatório**: estoque detalhado, resumo de vendas e ranking de produtos
- **Dados de exemplo** e um **roteiro de testes** que tenta "quebrar" o banco de propósito

---

## 🗂️ Modelo de dados

```mermaid
erDiagram
    CATEGORIAS ||--o{ PRODUTOS : classifica
    MARCAS     ||--o{ PRODUTOS : fabrica
    PRODUTOS   ||--o{ VARIACOES : "tem tamanhos/cores"
    CLIENTES   ||--o{ VENDAS : faz
    VENDAS     ||--|{ ITENS_VENDA : contem
    VARIACOES  ||--o{ ITENS_VENDA : "é vendida em"

    CATEGORIAS { int id_categoria PK
                 varchar nome UK }
    MARCAS     { int id_marca PK
                 varchar nome UK }
    CLIENTES   { int id_cliente PK
                 varchar nome
                 char cpf UK "11 dígitos"
                 varchar email UK
                 date data_cadastro }
    PRODUTOS   { int id_produto PK
                 varchar nome
                 int id_categoria FK
                 int id_marca FK
                 numeric preco "maior que 0"
                 boolean ativo }
    VARIACOES  { int id_variacao PK
                 int id_produto FK
                 varchar tamanho
                 varchar cor
                 varchar codigo_sku UK
                 int estoque "nunca negativo" }
    VENDAS     { int id_venda PK
                 int id_cliente FK
                 timestamp data_venda
                 varchar canal "loja ou online"
                 varchar forma_pagamento
                 varchar status "concluida ou cancelada" }
    ITENS_VENDA { int id_venda FK
                  int id_variacao FK
                  int quantidade
                  numeric preco_unitario }
```

**Decisões de modelagem:**

- **Produto ≠ variação.** "Camiseta Básica" é o produto; "Camiseta Básica M Preta" é a variação. O estoque fica na variação, porque cada tamanho e cor tem a sua quantidade.
- **O preço fica guardado no item da venda.** Se o produto mudar de preço amanhã, as vendas antigas continuam com o valor correto.
- **Vendas não são apagadas, são canceladas.** O histórico é mantido e o estoque é devolvido.

---

## 🔄 Fluxo do controle de estoque

![Fluxograma do controle de estoque](docs/fluxograma_estoque.png)

---

## 📁 Estrutura do repositório

```
loja-roupas-postgresql/
├── README.md
├── docs/
│   ├── diagrama_er.png
│   └── fluxograma_estoque.png
└── sql/
    ├── 01_tabelas.sql         # criação das tabelas
    ├── 02_indices.sql         # índices
    ├── 03_triggers.sql        # controle automático de estoque
    ├── 04_views.sql           # relatórios
    ├── 05_dados_exemplo.sql   # dados fictícios
    └── 06_testes.sql          # testes das regras
```

---

## ▶️ Como executar

**Pré-requisito:** PostgreSQL instalado (testado na versão 16).

1. Crie um banco vazio:
   ```sql
   CREATE DATABASE loja_roupas;
   ```
2. Conecte-se a ele e execute os arquivos da pasta `sql/` **na ordem numérica** (01 → 05).
   - **No DBeaver:** abra cada arquivo e use **Alt+X** (executar script).
   - **No terminal:**
     ```bash
     psql -d loja_roupas -f sql/01_tabelas.sql
     psql -d loja_roupas -f sql/02_indices.sql
     psql -d loja_roupas -f sql/03_triggers.sql
     psql -d loja_roupas -f sql/04_views.sql
     psql -d loja_roupas -f sql/05_dados_exemplo.sql
     ```
3. Rode os comandos de `06_testes.sql` **um de cada vez**. Alguns devem dar erro de propósito: é a regra funcionando.

---

## 🔎 Exemplos de consulta

```sql
-- Estoque com nomes em vez de IDs
SELECT produto, tamanho, cor, estoque FROM vw_estoque ORDER BY produto;

-- Peças acabando
SELECT produto, tamanho, cor, estoque FROM vw_estoque WHERE estoque <= 5;

-- Total de cada venda
SELECT * FROM vw_vendas_resumo ORDER BY data_venda;

-- Produtos mais vendidos (ignora vendas canceladas)
SELECT * FROM vw_produtos_mais_vendidos;
```

---

## 🧪 Testes realizados

| Teste | Resultado esperado |
|---|---|
| Vender 99 unidades de uma peça com 4 em estoque | ❌ `Estoque insuficiente para a variação 10.` |
| Cancelar uma venda | ✅ as peças voltam para o estoque |
| Adicionar item numa venda cancelada | ❌ `A venda 2 está cancelada` |
| Reativar a venda | ✅ o estoque baixa de novo |
| Alterar a quantidade de um item de 2 para 5 | ✅ o estoque cai mais 3 unidades |
| CPF `'123.456.789-01'` | ❌ não cabe em `CHAR(11)` |
| CPF `'1234567890A'` | ❌ barrado pelo `CHECK` |

---

## 📚 O que aprendi

- Modelagem relacional e relacionamentos 1:N e N:N
- Constraints como primeira linha de defesa dos dados
- Quando criar índices (e por que o Postgres não os cria nas chaves estrangeiras)
- Funções e triggers em PL/pgSQL (`TG_OP`, `NEW`, `OLD`, `FOUND`, `RAISE EXCEPTION`)
- Views, `JOIN`, `LEFT JOIN`, `GROUP BY` e `COALESCE`
- Ler mensagens de erro com calma: cada uma ensinou alguma coisa

---

## 🛠️ Tecnologias

PostgreSQL 16 · PL/pgSQL · DBeaver

---

## 👩‍💻 Autora

**Graziela Romualdo**
[LinkedIn](https://www.linkedin.com/in/SEU-PERFIL) <!-- troque pelo link do seu perfil -->

> Os dados deste projeto são fictícios e usados apenas para estudo.
